<?php
/*
		NEVER,NEVER upgrade a plugin by overwriting the existing folders
		The widgets are now located in the widgets folder
*/
?>